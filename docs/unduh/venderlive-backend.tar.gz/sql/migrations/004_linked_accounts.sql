-- One user can be reached through several sign-in methods (google, facebook, telegram, phone).
-- Whichever method is used, the login lands on the same account and the same public ID.
CREATE TABLE IF NOT EXISTS linked_accounts (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id      BIGINT UNSIGNED NOT NULL,
  provider     VARCHAR(16) NOT NULL,
  provider_uid VARCHAR(191) NOT NULL,
  label        VARCHAR(191) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_provider_uid (provider, provider_uid),
  UNIQUE KEY uk_user_provider (user_id, provider),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Accounts that already exist keep working: their original sign-in becomes a link.
INSERT IGNORE INTO linked_accounts (user_id, provider, provider_uid)
SELECT id,
       CASE WHEN firebase_uid LIKE 'wa\_%' THEN 'phone' ELSE 'firebase' END,
       firebase_uid
FROM users;

CREATE TABLE IF NOT EXISTS blocked_users (
  user_id         BIGINT UNSIGNED NOT NULL,
  blocked_user_id BIGINT UNSIGNED NOT NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, blocked_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
