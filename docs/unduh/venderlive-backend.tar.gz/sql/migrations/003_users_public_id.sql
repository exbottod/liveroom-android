-- Public user ID shown in the app, e.g. "ID: 255800". Random six digits, unique.
ALTER TABLE users ADD COLUMN IF NOT EXISTS public_id CHAR(6) NULL AFTER id;
ALTER TABLE users ADD UNIQUE KEY IF NOT EXISTS uk_public_id (public_id);
