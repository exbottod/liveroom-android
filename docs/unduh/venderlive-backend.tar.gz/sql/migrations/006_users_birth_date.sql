-- Birthday chosen on the Edit profile page.
ALTER TABLE users ADD COLUMN IF NOT EXISTS birth_date DATE NULL AFTER country;
