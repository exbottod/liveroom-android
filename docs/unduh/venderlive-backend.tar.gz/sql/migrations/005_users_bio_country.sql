-- Public profile: a short bio and the country flag shown next to the nickname.
ALTER TABLE users ADD COLUMN IF NOT EXISTS bio VARCHAR(160) NULL AFTER gender;
ALTER TABLE users ADD COLUMN IF NOT EXISTS country CHAR(2) NULL AFTER bio;
