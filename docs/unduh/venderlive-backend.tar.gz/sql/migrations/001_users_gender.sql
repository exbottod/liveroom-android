-- First-run profile screen: gender picked by the user ("male" or "female").
-- MariaDB understands IF NOT EXISTS, so re-running this is safe.
ALTER TABLE users ADD COLUMN IF NOT EXISTS gender VARCHAR(8) NULL AFTER avatar;
