/**
 * One-time job: copy every account already in MariaDB into Firestore, so the panel's
 * User page is complete even for people who registered before the mirror existed.
 *
 * Safe to run more than once: each account is written with merge, nothing is deleted,
 * and the database stays the source of truth.
 *
 *   cd /opt/venderlive/backend && sudo node scripts/backfill-users.mjs
 */
import 'dotenv/config';
import { pool, listUsersForBackfill } from '../src/db.js';
import { syncUser } from '../src/firestore.js';

let cursor = 0;
let total = 0;
let failed = 0;

for (;;) {
  const rows = await listUsersForBackfill(cursor, 200);
  if (rows.length === 0) break;
  for (const row of rows) {
    try {
      await syncUser(row);
      total += 1;
    } catch (error) {
      failed += 1;
      console.error('gagal', row.public_id ?? row.id, error?.message ?? error);
    }
    cursor = row.id;
  }
  console.log(`tersalin ${total} akun, id terakhir ${cursor}`);
}

console.log(`selesai: ${total} akun disalin${failed ? `, ${failed} gagal` : ''}`);
await pool.end();
process.exit(failed > 0 ? 1 : 0);
