import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { accountRouter } from './routes/account.js';
import { asetRouter } from './routes/aset.js';
import { authRouter } from './routes/auth.js';
import { meRouter } from './routes/me.js';
import { otpRouter } from './routes/otp.js';
import { profileRouter } from './routes/profile.js';
import { usersRouter } from './routes/users.js';
import { pool } from './db.js';

// A rejected promise used to end the whole process (Express 4 does not catch async
// errors), which showed up as a Caddy 502. Log it and keep serving instead.
process.on('unhandledRejection', (reason) => console.error('[unhandledRejection]', reason));
process.on('uncaughtException', (error) => console.error('[uncaughtException]', error));

const app = express();
app.use(cors());
app.use(express.json({ limit: '6mb' }));
app.use('/uploads', express.static(process.env.UPLOADS_DIR ?? 'uploads', { maxAge: '7d' }));

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, db: 'up' });
  } catch {
    res.status(503).json({ ok: false, db: 'down' });
  }
});

app.use('/v1/auth/otp', otpRouter);
app.use('/v1/auth', authRouter);
app.use('/v1/me', meRouter);
app.use('/v1/profile', profileRouter);
app.use('/v1/account', accountRouter);
app.use('/v1/aset-upload', asetRouter);
app.use('/v1/users', usersRouter);

app.use((_req, res) => res.status(404).json({ code: 404, message: 'Not found' }));

const port = Number(process.env.PORT ?? 8080);
app.listen(port, () => {
  console.log(`venderlive-backend listening on :${port}`);
});
