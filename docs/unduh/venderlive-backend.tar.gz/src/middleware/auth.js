import jwt from 'jsonwebtoken';

export function signSession(user) {
  return jwt.sign(
    { sub: String(user.id), phone: user.phone ?? null },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN ?? '30d' },
  );
}

export function requireAuth(req, res, next) {
  const header = req.headers.authorization ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ code: 401, message: 'Missing token' });
  }

  try {
    req.auth = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch {
    return res.status(401).json({ code: 401, message: 'Invalid or expired token' });
  }
}
