import fs from 'node:fs';
import admin from 'firebase-admin';

/**
 * Initialises the Firebase Admin SDK with our own project's service account.
 *
 * Two ways to supply the credential, checked in this order:
 *   1. FIREBASE_SERVICE_ACCOUNT_JSON - the JSON itself, or base64 of it (handy for Docker secrets).
 *   2. GOOGLE_APPLICATION_CREDENTIALS - path to the downloaded service account JSON.
 */
function loadCredential() {
  const inline = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (inline && inline.trim()) {
    const text = inline.trim().startsWith('{')
      ? inline
      : Buffer.from(inline, 'base64').toString('utf8');
    return admin.credential.cert(JSON.parse(text));
  }

  const path = process.env.GOOGLE_APPLICATION_CREDENTIALS;
  if (path && fs.existsSync(path)) {
    return admin.credential.cert(JSON.parse(fs.readFileSync(path, 'utf8')));
  }

  throw new Error(
    'Firebase service account missing. Set GOOGLE_APPLICATION_CREDENTIALS to the JSON path ' +
      '(default /opt/venderlive/secrets/firebase-service-account.json) or set ' +
      'FIREBASE_SERVICE_ACCOUNT_JSON to the JSON or its base64.',
  );
}

if (!admin.apps.length) {
  admin.initializeApp({ credential: loadCredential() });
}

export async function verifyFirebaseIdToken(idToken) {
  const decoded = await admin.auth().verifyIdToken(idToken);
  const signIn = decoded.firebase?.sign_in_provider ?? '';
  const provider = signIn === 'google.com' ? 'google'
    : signIn === 'facebook.com' ? 'facebook'
    : signIn === 'phone' ? 'phone'
    : 'firebase';
  return {
    uid: decoded.uid,
    phone: decoded.phone_number ?? null,
    provider,
    email: decoded.email ?? null,
  };
}
