import { readFileSync } from 'node:fs';
import { Router } from 'express';
import { pool, findOrCreateUserByPhone } from '../db.js';
import { signSession } from '../middleware/auth.js';

export const otpRouter = Router();

/**
 * Local WhatsApp gateway on the same VPS (port 8099).
 * It exposes GET /health, GET /qr.png and POST /send with an `x-secret` header.
 * The code itself is generated and checked here; the gateway only delivers the text.
 */
const WA_BASE = process.env.WA_OTP_BASE ?? 'http://127.0.0.1:8099';
const CODE_TTL_MINUTES = 5;
const RESEND_COOLDOWN_SECONDS = 60;
const MAX_ATTEMPTS = 5;

/** The gateway wants its shared secret in `x-secret`; read it from the env or its own env file. */
function gatewaySecret() {
  if (process.env.WA_OTP_SECRET) return process.env.WA_OTP_SECRET.trim();
  const files = [
    '/opt/wa-otp/.env',
    '/opt/wa-otp/server.env',
    '/etc/default/wa-otp',
  ];
  for (const file of files) {
    try {
      const text = readFileSync(file, 'utf8');
      const match = text.match(/^\s*(?:WA_OTP_SECRET|OTP_SECRET|SECRET)\s*=\s*(.+)$/m);
      if (match) return match[1].trim().replace(/^["']|["']$/g, '');
    } catch {
      /* try the next candidate */
    }
  }
  return null;
}

export function normalizePhone(raw) {
  const text = String(raw ?? '').trim();
  const digits = text.replace(/[^0-9]/g, '');
  if (!digits) return null;
  // A leading + means the app already sent a full international number.
  if (text.startsWith('+')) return `+${digits}`;
  if (digits.startsWith('62')) return `+${digits}`;
  if (digits.startsWith('0')) return `+62${digits.slice(1)}`;
  if (digits.startsWith('8')) return `+62${digits}`;
  return `+${digits}`;
}

function sixDigitCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

/** Deliver one WhatsApp text through the gateway. Returns { ok, detail }. */
export async function sendWhatsApp(phone, message) {
  const digits = phone.replace(/[^0-9]/g, '');
  const secret = gatewaySecret();
  const headers = { 'Content-Type': 'application/json' };
  if (secret) headers['x-secret'] = secret;

  // The gateway's body field names differ between builds, so send every plausible one.
  const payload = {
    numbers: [digits],
    number: digits,
    to: digits,
    phone: digits,
    nomor: digits,
    message,
    text: message,
    pesan: message,
  };

  let res;
  try {
    res = await fetch(`${WA_BASE}/send`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(25000),
    });
  } catch (err) {
    console.error('[otp] gateway unreachable:', err?.message);
    return { ok: false, detail: 'Server WhatsApp tidak bisa dihubungi' };
  }

  const text = await res.text();
  let body = null;
  try {
    body = JSON.parse(text || '{}');
  } catch {
    body = null;
  }

  const flagOk =
    body?.ok === 1 || body?.ok === true || body?.success === true || body?.status === 'sent' || Boolean(body?.id);

  if (res.ok && (flagOk || (body && body.error == null && body.ok == null))) {
    return { ok: true, detail: 'sent' };
  }

  const detail =
    body?.error || body?.e || body?.message || `Gateway menolak (HTTP ${res.status})`;
  console.error('[otp] gateway rejected:', res.status, text.slice(0, 300));
  return { ok: false, detail: String(detail) };
}

/** POST /v1/auth/otp/request  { phone } */
otpRouter.post('/request', async (req, res) => {
  const phone = normalizePhone(req.body?.phone);
  if (!phone) return res.status(400).json({ code: 400, message: 'phone is required' });

  try {
    const [recent] = await pool.execute(
      `SELECT id FROM otp_codes WHERE phone = ? AND created_at > (NOW() - INTERVAL ${RESEND_COOLDOWN_SECONDS} SECOND) ORDER BY id DESC LIMIT 1`,
      [phone],
    );
    if (recent.length > 0) {
      return res.status(429).json({ code: 429, message: 'Tunggu sebentar sebelum minta kode lagi' });
    }

    const code = sixDigitCode();
    await pool.execute('DELETE FROM otp_codes WHERE phone = ?', [phone]);
    await pool.execute(
      `INSERT INTO otp_codes (phone, code, expires_at) VALUES (?, ?, (NOW() + INTERVAL ${CODE_TTL_MINUTES} MINUTE))`,
      [phone, code],
    );

    const message = `Kode VenderLive kamu: ${code}. Berlaku ${CODE_TTL_MINUTES} menit. Jangan bagikan kode ini ke siapa pun.`;
    const sent = await sendWhatsApp(phone, message);
    if (!sent.ok) {
      await pool.execute('DELETE FROM otp_codes WHERE phone = ?', [phone]);
      return res.status(502).json({ code: 502, message: sent.detail });
    }

    return res.json({ code: 0, data: { sent: true, phone } });
  } catch (err) {
    console.error('[otp/request]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});

/** POST /v1/auth/otp/verify  { phone, code } */
otpRouter.post('/verify', async (req, res) => {
  const phone = normalizePhone(req.body?.phone);
  const code = String(req.body?.code ?? '').replace(/[^0-9]/g, '');
  if (!phone || code.length < 4) {
    return res.status(400).json({ code: 400, message: 'phone and code are required' });
  }

  try {
    const [rows] = await pool.execute(
      'SELECT id, code, attempts, expires_at, (expires_at < NOW()) AS expired FROM otp_codes WHERE phone = ? ORDER BY id DESC LIMIT 1',
      [phone],
    );
    if (rows.length === 0) {
      return res.status(401).json({ code: 401, message: 'Kode tidak ditemukan, minta kode baru' });
    }

    const row = rows[0];
    if (Number(row.expired) === 1) {
      await pool.execute('DELETE FROM otp_codes WHERE id = ?', [row.id]);
      return res.status(401).json({ code: 401, message: 'Kode sudah kedaluwarsa, minta kode baru' });
    }
    if (Number(row.attempts) >= MAX_ATTEMPTS) {
      await pool.execute('DELETE FROM otp_codes WHERE id = ?', [row.id]);
      return res.status(401).json({ code: 401, message: 'Terlalu banyak percobaan, minta kode baru' });
    }
    if (String(row.code) !== code) {
      await pool.execute('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?', [row.id]);
      return res.status(401).json({ code: 401, message: 'Kode salah' });
    }

    await pool.execute('DELETE FROM otp_codes WHERE phone = ?', [phone]);

    const { user, isNew } = await findOrCreateUserByPhone(phone);
    const accessToken = signSession(user);
    return res.json({
      code: 0,
      data: {
        access_token: accessToken,
        user: {
          id: String(user.id),
          public_id: user.public_id ?? null,
          nickname: user.nickname,
          avatar: user.avatar,
          phone: user.phone,
          level: user.level,
          gender: user.gender ?? null,
          is_new: isNew || !user.gender,
        },
      },
    });
  } catch (err) {
    console.error('[otp/verify]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});
