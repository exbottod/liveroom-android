import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { findUserById, updateAvatar, updatePublicProfile, updateUserProfile } from '../db.js';

export const profileRouter = Router();

const GENDERS = new Set(['male', 'female']);

/**
 * POST /v1/profile
 * Body: { "nickname": "budi", "gender": "male" }
 *
 * Called once by the app right after the first login, before the home screen.
 * The invite code is not part of this version.
 */
profileRouter.post('/', requireAuth, async (req, res) => {
  const rawName = req.body?.nickname;
  const gender = req.body?.gender;

  if (typeof rawName !== 'string') {
    return res.status(400).json({ code: 400, message: 'nickname is required' });
  }
  const nickname = rawName.trim();
  if (nickname.length < 2 || nickname.length > 30) {
    return res.status(400).json({ code: 400, message: 'nickname must be 2-30 characters' });
  }
  if (!GENDERS.has(gender)) {
    return res.status(400).json({ code: 400, message: 'gender must be male or female' });
  }

  try {
    await updateUserProfile({ id: req.auth.sub, nickname, gender });
    const user = await findUserById(req.auth.sub);
    if (!user) {
      return res.status(404).json({ code: 404, message: 'User not found' });
    }
    return res.json({
      code: 0,
      data: {
        id: String(user.id),
        public_id: user.public_id ?? null,
        nickname: user.nickname,
        avatar: user.avatar,
        phone: user.phone,
        level: user.level,
        gender: user.gender ?? null,
      },
    });
  } catch (err) {
    console.error('[profile]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});

/**
 * PATCH /v1/profile
 * Body: { "nickname": "...", "bio": "...", "country": "ID" }
 * The pencil button on a profile page. Every field is optional.
 */
profileRouter.patch('/', requireAuth, async (req, res) => {
  const { nickname, bio, country, birth_date: birthDate } = req.body ?? {};
  const fields = { id: req.auth.sub };

  if (nickname !== undefined) {
    if (typeof nickname !== 'string') {
      return res.status(400).json({ code: 400, message: 'nickname must be a string' });
    }
    const clean = nickname.trim();
    if (clean.length < 2 || clean.length > 30) {
      return res.status(400).json({ code: 400, message: 'nickname must be 2-30 characters' });
    }
    fields.nickname = clean;
  }
  if (bio !== undefined) {
    if (typeof bio !== 'string' || bio.length > 100) {
      return res.status(400).json({ code: 400, message: 'bio must be at most 100 characters' });
    }
    fields.bio = bio.trim();
  }
  if (birthDate !== undefined) {
    // Empty string clears the birthday; otherwise it must be YYYY-MM-DD and in the past.
    if (birthDate === null || birthDate === '') {
      fields.birthDate = null;
    } else if (typeof birthDate !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) {
      return res.status(400).json({ code: 400, message: 'birth_date must be YYYY-MM-DD' });
    } else if (new Date(birthDate) > new Date()) {
      return res.status(400).json({ code: 400, message: 'birth_date cannot be in the future' });
    } else {
      fields.birthDate = birthDate;
    }
  }
  if (country !== undefined) {
    if (typeof country !== 'string' || !/^[A-Z]{2}$/.test(country)) {
      return res.status(400).json({ code: 400, message: 'country must be a two-letter code' });
    }
    fields.country = country;
  }

  try {
    await updatePublicProfile(fields);
    const user = await findUserById(req.auth.sub);
    return res.json({ code: 0, data: publicUser(user) });
  } catch (err) {
    console.error('[profile/patch]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});

const AVATAR_DIR = process.env.AVATAR_DIR ?? path.join(process.cwd(), 'uploads', 'avatars');

/** POST /v1/profile/avatar  Body: { "image_base64": "<jpeg or png, base64>" } */
profileRouter.post('/avatar', requireAuth, async (req, res) => {
  const raw = req.body?.image_base64;
  if (typeof raw !== 'string' || raw.length < 100) {
    return res.status(400).json({ code: 400, message: 'image_base64 is required' });
  }
  const base64 = raw.includes(',') ? raw.slice(raw.indexOf(',') + 1) : raw;
  let buffer;
  try {
    buffer = Buffer.from(base64, 'base64');
  } catch {
    return res.status(400).json({ code: 400, message: 'image is not valid base64' });
  }
  if (buffer.length > 4 * 1024 * 1024) {
    return res.status(413).json({ code: 413, message: 'Foto terlalu besar' });
  }

  try {
    await fs.mkdir(AVATAR_DIR, { recursive: true });
    const name = `u${req.auth.sub}-${Date.now()}.jpg`;
    await fs.writeFile(path.join(AVATAR_DIR, name), buffer);
    const url = `${process.env.PUBLIC_BASE_URL ?? ''}/uploads/avatars/${name}`;
    await updateAvatar(req.auth.sub, url);
    const user = await findUserById(req.auth.sub);
    return res.json({ code: 0, data: publicUser(user) });
  } catch (err) {
    console.error('[profile/avatar]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});

function publicUser(user) {
  return {
    id: String(user.id),
    public_id: user.public_id ?? null,
    nickname: user.nickname,
    avatar: user.avatar,
    phone: user.phone,
    level: user.level,
    gender: user.gender ?? null,
    bio: user.bio ?? null,
    country: user.country ?? null,
    birth_date: toDateString(user.birth_date),
  };
}

/** MySQL hands back a Date object; the app expects YYYY-MM-DD. */
function toDateString(value) {
  if (!value) return null;
  if (typeof value === 'string') return value.slice(0, 10);
  return new Date(value).toISOString().slice(0, 10);
}
