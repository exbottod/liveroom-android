import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { verifyFirebaseIdToken } from '../firebase.js';
import {
  LINK_PROVIDERS,
  deleteUserAccount,
  linkAccount,
  listBlocked,
  listLinks,
  unblockUser,
  unlinkAccount,
} from '../db.js';

export const accountRouter = Router();

const PROVIDERS = new Set(LINK_PROVIDERS);

/** GET /v1/account/links -> which sign-in methods are tied to this account. */
accountRouter.get('/links', requireAuth, async (req, res) => {
  const rows = await listLinks(req.auth.sub);
  const linked = new Set(rows.map((r) => r.provider));
  return res.json({
    code: 0,
    data: LINK_PROVIDERS.map((provider) => ({ provider, linked: linked.has(provider) })),
  });
});

/**
 * POST /v1/account/links
 * Body: { "provider": "google" | "facebook" | "telegram" | "phone", "id_token": "<firebase id token>" }
 * Ties one more sign-in method to the signed-in account.
 */
accountRouter.post('/links', requireAuth, async (req, res) => {
  const provider = req.body?.provider;
  const idToken = req.body?.id_token;
  if (!PROVIDERS.has(provider)) {
    return res.status(400).json({ code: 400, message: 'provider is not supported' });
  }
  if (typeof idToken !== 'string' || !idToken) {
    return res.status(400).json({ code: 400, message: 'id_token is required' });
  }
  try {
    const proof = await verifyFirebaseIdToken(idToken);
    if (proof.provider !== provider) {
      return res.status(400).json({ code: 400, message: 'The token does not belong to that provider' });
    }
    const result = await linkAccount({
      userId: req.auth.sub,
      provider,
      providerUid: proof.uid,
      label: proof.email ?? proof.phone ?? null,
    });
    if (result === 'taken') {
      return res.status(409).json({ code: 409, message: 'Akun ini sudah terkait dengan pengguna lain' });
    }
    return res.json({ code: 0, data: { provider, linked: true } });
  } catch (err) {
    if (err?.code?.startsWith?.('auth/')) {
      return res.status(401).json({ code: 401, message: 'Firebase token rejected' });
    }
    console.error('[account/link]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});

/** DELETE /v1/account/links/:provider */
accountRouter.delete('/links/:provider', requireAuth, async (req, res) => {
  const { provider } = req.params;
  if (!PROVIDERS.has(provider)) {
    return res.status(400).json({ code: 400, message: 'provider is not supported' });
  }
  const result = await unlinkAccount(req.auth.sub, provider);
  if (result === 'last') {
    return res.status(400).json({ code: 400, message: 'Tidak bisa melepas satu-satunya cara masuk' });
  }
  return res.json({ code: 0, data: { provider, linked: false } });
});

/** GET /v1/account/blocked */
accountRouter.get('/blocked', requireAuth, async (req, res) => {
  const rows = await listBlocked(req.auth.sub);
  return res.json({
    code: 0,
    data: rows.map((r) => ({
      id: String(r.id),
      public_id: r.public_id ?? null,
      nickname: r.nickname,
      avatar: r.avatar,
    })),
  });
});

/** DELETE /v1/account/blocked/:id */
accountRouter.delete('/blocked/:id', requireAuth, async (req, res) => {
  await unblockUser(req.auth.sub, req.params.id);
  return res.json({ code: 0, data: { unblocked: true } });
});

/** DELETE /v1/account -> removes the account for good. */
accountRouter.delete('/', requireAuth, async (req, res) => {
  await deleteUserAccount(req.auth.sub);
  return res.json({ code: 0, data: { deleted: true } });
});
