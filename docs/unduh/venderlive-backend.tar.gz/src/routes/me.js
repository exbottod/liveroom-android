import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { findUserById } from '../db.js';

export const meRouter = Router();

meRouter.get('/', requireAuth, async (req, res) => {
  const user = await findUserById(req.auth.sub);
  if (!user) {
    return res.status(404).json({ code: 404, message: 'User not found' });
  }
  return res.json({
    code: 0,
    data: {
      id: String(user.id),
      public_id: user.public_id ?? null,
      nickname: user.nickname,
      avatar: user.avatar,
      phone: user.phone,
      level: user.level,
      gender: user.gender ?? null,
    },
  });
});
