import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import admin from 'firebase-admin';
import './../firebase.js';
import { verifyFirebaseIdToken } from '../firebase.js';

/**
 * Panel asset uploads (SVIP medal, label, avatar frame).
 *
 * Firebase Storage needs a billing account, so the files live here instead: the panel
 * posts a base64 image with its Firebase ID token, we check the account is an admin,
 * write the file under uploads/aset and answer with its public URL. /uploads is already
 * served statically, so the app loads the picture straight from this server.
 */
export const asetRouter = express.Router();

const ASET_DIR = process.env.ASET_DIR ?? path.join(process.cwd(), 'uploads', 'aset');
const MAX_BYTES = 6 * 1024 * 1024;
const EXT = { png: 'png', jpeg: 'jpg', jpg: 'jpg', webp: 'webp', gif: 'gif' };

function adminEmails() {
  return (process.env.ADMIN_EMAILS ?? '')
    .split(',')
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);
}

async function isAdmin(uid) {
  const email = await admin.auth().getUser(uid).then((record) => (record.email ?? '').toLowerCase()).catch(() => '');
  if (email && adminEmails().includes(email)) return true;
  const doc = await admin.firestore().collection('admins').doc(uid).get().catch(() => null);
  return Boolean(doc?.exists);
}

function extensionFor(raw, fallback) {
  const header = /^data:image\/([a-z]+);base64,/i.exec(raw);
  if (header) return EXT[header[1].toLowerCase()] ?? null;
  const clean = String(fallback ?? '').toLowerCase().replace('.', '');
  return EXT[clean] ?? 'png';
}

/** POST /v1/aset-upload  Body: { "image_base64": "data:image/png;base64,..." } */
asetRouter.post('/', async (req, res) => {
  try {
    const header = req.get('authorization') ?? '';
    const token = header.toLowerCase().startsWith('bearer ') ? header.slice(7).trim() : '';
    if (!token) return res.status(401).json({ code: 401, message: 'Token admin diperlukan' });

    let uid;
    try {
      ({ uid } = await verifyFirebaseIdToken(token));
    } catch {
      return res.status(401).json({ code: 401, message: 'Token admin tidak valid' });
    }

    if (!(await isAdmin(uid))) {
      return res.status(403).json({ code: 403, message: 'Akun ini belum terdaftar sebagai admin' });
    }

    const raw = req.body?.image_base64;
    if (typeof raw !== 'string' || raw.length < 100) {
      return res.status(400).json({ code: 400, message: 'image_base64 wajib diisi' });
    }
    const ext = extensionFor(raw, req.body?.ext);
    if (!ext) return res.status(415).json({ code: 415, message: 'Hanya PNG, JPG, WebP, atau GIF' });

    const base64 = raw.includes(',') ? raw.slice(raw.indexOf(',') + 1) : raw;
    const buffer = Buffer.from(base64, 'base64');
    if (buffer.length === 0) return res.status(400).json({ code: 400, message: 'Gambar kosong' });
    if (buffer.length > MAX_BYTES) return res.status(413).json({ code: 413, message: 'Gambar lebih dari 6 MB' });

    fs.mkdirSync(ASET_DIR, { recursive: true });
    const name = `${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
    fs.writeFileSync(path.join(ASET_DIR, name), buffer);

    const base = (process.env.PUBLIC_BASE_URL ?? '').replace(/\/$/, '');
    return res.json({ code: 0, data: { url: `${base}/uploads/aset/${name}`, size: buffer.length } });
  } catch (err) {
    console.error('[aset-upload]', err);
    return res.status(500).json({ code: 500, message: 'Gagal menyimpan gambar' });
  }
});
