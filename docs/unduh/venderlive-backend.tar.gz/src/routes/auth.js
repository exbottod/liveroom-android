import { Router } from 'express';
import { verifyFirebaseIdToken } from '../firebase.js';
import { findOrCreateUser } from '../db.js';
import { signSession } from '../middleware/auth.js';

export const authRouter = Router();

/**
 * POST /v1/auth/firebase-login
 * Body: { "id_token": "<firebase id token>" }
 * Firebase proves phone ownership; our own VPS issues the session.
 */
authRouter.post('/firebase-login', async (req, res) => {
  const idToken = req.body?.id_token;
  if (!idToken || typeof idToken !== 'string') {
    return res.status(400).json({ code: 400, message: 'id_token is required' });
  }

  try {
    const { uid, phone, provider } = await verifyFirebaseIdToken(idToken);
    const { user, isNew } = await findOrCreateUser({ uid, phone, provider });
    const accessToken = signSession(user);

    return res.json({
      code: 0,
      data: {
        access_token: accessToken,
        user: {
          id: String(user.id),
          public_id: user.public_id ?? null,
          nickname: user.nickname,
          avatar: user.avatar,
          phone: user.phone,
          level: user.level,
          gender: user.gender ?? null,
          is_new: isNew || !user.gender,
        },
      },
    });
  } catch (err) {
    if (err?.code?.startsWith?.('auth/')) {
      return res.status(401).json({ code: 401, message: 'Firebase token rejected' });
    }
    console.error('[auth/firebase-login]', err);
    return res.status(500).json({ code: 500, message: 'Internal error' });
  }
});
