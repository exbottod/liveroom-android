import { Router } from 'express';
import { findUserByPublicId, profileStats } from '../db.js';

export const usersRouter = Router();

/**
 * GET /v1/users/:publicId
 * The profile page opened from a room seat or from a list of users.
 * No auth needed: a public profile is what a nickname in a room leads to.
 */
usersRouter.get('/:publicId', async (req, res) => {
  try {
  const { publicId } = req.params;
  if (!/^\d{4,12}$/.test(publicId)) {
    return res.status(400).json({ code: 400, message: 'public ID is not valid' });
  }
  const user = await findUserByPublicId(publicId);
  if (!user) {
    return res.status(404).json({ code: 404, message: 'Pengguna tidak ditemukan' });
  }
  const stats = await profileStats(user.id);
  return res.json({
    code: 0,
    data: {
      id: String(user.id),
      public_id: user.public_id,
      nickname: user.nickname,
      avatar: user.avatar,
      gender: user.gender ?? null,
      level: user.level,
      bio: user.bio ?? null,
      country: user.country ?? null,
      birth_date: user.birth_date
        ? (typeof user.birth_date === 'string'
            ? user.birth_date.slice(0, 10)
            : new Date(user.birth_date).toISOString().slice(0, 10))
        : null,
      stats,
    },
  });
  } catch (err) {
    console.error('[users/:publicId]', err);
    return res.status(500).json({ code: 500, message: 'Gagal memuat profil' });
  }
});
