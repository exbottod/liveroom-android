import admin from 'firebase-admin';
import './firebase.js';

/**
 * Accounts live in MariaDB; this keeps a readable copy in Firestore so the panel and
 * the Firebase Console can list them, the way Viza does it. The database stays the
 * source of truth: a Firestore failure only logs a warning and never blocks a login.
 */
const USERS = 'users';

function db() {
  return admin.firestore();
}

const text = (value) => (value === undefined ? null : value);

export async function syncUser(row) {
  if (!row) return;
  const key = String(row.public_id ?? row.publicId ?? row.id ?? '').trim();
  if (!key) return;
  const ref = db().collection(USERS).doc(key);
  try {
    const payload = {
      publicId: key,
      userId: row.id ?? null,
      nickname: text(row.nickname),
      avatar: text(row.avatar),
      gender: text(row.gender),
      phone: text(row.phone),
      bio: text(row.bio),
      country: text(row.country),
      birthDate: text(row.birth_date ?? row.birthDate),
      level: Number(row.level ?? 0),
      updatedAt: Date.now(),
    };
    const snapshot = await ref.get();
    if (!snapshot.exists) {
      payload.createdAt = Date.now();
      if (row.created_at) payload.registeredAt = new Date(row.created_at).getTime();
      payload.createdAt = payload.registeredAt ?? payload.createdAt;
    }
    await ref.set(payload, { merge: true });
  } catch (error) {
    console.warn('[firestore] could not mirror user', key, error?.message ?? error);
  }
}

/** Read the row first so the copy always matches the database. */
export async function syncUserById(loader, id) {
  try {
    const row = await loader(id);
    if (row) await syncUser(row);
  } catch (error) {
    console.warn('[firestore] mirror skipped', error?.message ?? error);
  }
}

export async function deleteUserDoc(publicId) {
  if (!publicId) return;
  try {
    await db().collection(USERS).doc(String(publicId)).delete();
  } catch (error) {
    console.warn('[firestore] delete skipped', error?.message ?? error);
  }
}
