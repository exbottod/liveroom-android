import { syncUser, syncUserById, deleteUserDoc } from './firestore.js';
import mysql from 'mysql2/promise';

export const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
});

/** Six random digits, the ID a user shows to friends, e.g. "255800". */
function randomPublicId() {
  return String(100000 + Math.floor(Math.random() * 900000));
}

const PUBLIC_ID_COLUMNS = 'id, public_id, nickname, avatar, phone, level, gender, bio, country, birth_date';

/** Give a user their public ID the first time we see them after this feature shipped. */
async function ensurePublicId(row) {
  if (!row || row.public_id) return row;
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const candidate = randomPublicId();
    try {
      await pool.execute('UPDATE users SET public_id = ? WHERE id = ?', [candidate, row.id]);
      return { ...row, public_id: candidate };
    } catch (err) {
      if (err?.code !== 'ER_DUP_ENTRY') throw err;
    }
  }
  return row;
}

export async function findOrCreateUser({ uid, phone, provider = 'firebase' }) {
  // 1. A method linked to an account always opens that account.
  const linked = await findUserByLink(provider, uid);
  if (linked) return { user: await ensurePublicId(linked), isNew: false };

  // 2. Accounts made before linking existed are found by their original uid.
  const [rows] = await pool.execute(
    `SELECT ${PUBLIC_ID_COLUMNS} FROM users WHERE firebase_uid = ? LIMIT 1`,
    [uid],
  );

  if (rows.length > 0) {
    await linkAccount({ userId: rows[0].id, provider, providerUid: uid });
    return { user: await ensurePublicId(rows[0]), isNew: false };
  }

  const nickname = `user_${String(uid).slice(-6)}`;
  const publicId = await insertUser({ uid, phone, nickname });
  await linkAccount({ userId: publicId.id, provider, providerUid: uid });

  return {
    user: {
      id: publicId.id,
      public_id: publicId.publicId,
      nickname,
      avatar: null,
      phone,
      level: 0,
      gender: null,
    },
    isNew: true,
  };
}

/** Insert a user, retrying while a freshly drawn public ID collides. */
async function insertUser({ uid, phone, nickname }) {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const publicId = randomPublicId();
    try {
      const [result] = await pool.execute(
        'INSERT INTO users (public_id, firebase_uid, phone, nickname) VALUES (?, ?, ?, ?)',
        [publicId, uid, phone, nickname],
      );
      const created = await findUserById(result.insertId);
      if (created) await syncUser(created);
      return { id: result.insertId, publicId };
    } catch (err) {
      const duplicateId = err?.code === 'ER_DUP_ENTRY' && String(err.sqlMessage ?? '').includes('uk_public_id');
      if (duplicateId) continue;
      if (err?.code === 'ER_DUP_ENTRY' && String(err.sqlMessage ?? '').includes('uk_firebase_uid')) {
        const [rows] = await pool.execute(
          `SELECT ${PUBLIC_ID_COLUMNS} FROM users WHERE firebase_uid = ? LIMIT 1`,
          [uid],
        );
        if (rows.length > 0) {
          const user = await ensurePublicId(rows[0]);
          return { id: user.id, publicId: user.public_id };
        }
      }
      throw err;
    }
  }
  throw new Error('Could not allocate a public user ID');
}

/** Every account, oldest first. Used by the one-time Firestore backfill script. */
export async function listUsersForBackfill(afterId = 0, limit = 200) {
  const [rows] = await pool.execute(
    `SELECT ${PUBLIC_ID_COLUMNS}, created_at FROM users WHERE id > ? ORDER BY id ASC LIMIT ${Number(limit)}`,
    [afterId],
  );
  return rows;
}

export async function findUserById(id) {
  const [rows] = await pool.execute(
    `SELECT ${PUBLIC_ID_COLUMNS} FROM users WHERE id = ? LIMIT 1`,
    [id],
  );
  return ensurePublicId(rows[0] ?? null);
}

export async function findOrCreateUserByPhone(phone) {
  const [rows] = await pool.execute(
    `SELECT ${PUBLIC_ID_COLUMNS} FROM users WHERE phone = ? LIMIT 1`,
    [phone],
  );
  if (rows.length > 0) {
    await linkAccount({ userId: rows[0].id, provider: 'phone', providerUid: phone });
    return { user: await ensurePublicId(rows[0]), isNew: false };
  }

  const linkedByPhone = await findUserByLink('phone', phone);
  if (linkedByPhone) return { user: await ensurePublicId(linkedByPhone), isNew: false };

  const uid = `wa_${phone.replace(/[^0-9]/g, '')}`;
  const nickname = `user_${phone.slice(-4)}`;
  const created = await insertUser({ uid, phone, nickname });
  await linkAccount({ userId: created.id, provider: 'phone', providerUid: phone });
  return {
    user: {
      id: created.id,
      public_id: created.publicId,
      nickname,
      avatar: null,
      phone,
      level: 0,
      gender: null,
    },
    isNew: true,
  };
}

/** Name and gender picked on the first-run profile screen. */
export async function updateUserProfile({ id, nickname, gender }) {
  await pool.execute(
    'UPDATE users SET nickname = ?, gender = ? WHERE id = ?',
    [nickname, gender, id],
  );
  await syncUserById(findUserById, id);
}

/** Edits made from the pencil button on a profile: name, bio, country flag. */
export async function updatePublicProfile({ id, nickname, bio, country, birthDate }) {
  const sets = [];
  const values = [];
  if (nickname !== undefined) { sets.push('nickname = ?'); values.push(nickname); }
  if (bio !== undefined) { sets.push('bio = ?'); values.push(bio); }
  if (country !== undefined) { sets.push('country = ?'); values.push(country); }
  if (birthDate !== undefined) { sets.push('birth_date = ?'); values.push(birthDate); }
  if (sets.length === 0) return;
  values.push(id);
  await pool.execute(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`, values);
  await syncUserById(findUserById, id);
}

export async function updateAvatar(id, avatarUrl) {
  await pool.execute('UPDATE users SET avatar = ? WHERE id = ?', [avatarUrl, id]);
  await syncUserById(findUserById, id);
}

export async function findUserByPublicId(publicId) {
  const [rows] = await pool.execute(
    `SELECT ${PUBLIC_ID_COLUMNS} FROM users WHERE public_id = ? LIMIT 1`,
    [String(publicId)],
  );
  return rows[0] ?? null;
}

/**
 * Friends / following / followers. The social tables do not exist yet, so every
 * count is honestly zero instead of a made-up number.
 */
export async function profileStats(userId) {
  return { friends: 0, following: 0, followers: 0 };
}


// ---------------------------------------------------------------------------
// Linked sign-in methods. Any linked method opens the same account.
// ---------------------------------------------------------------------------

export const LINK_PROVIDERS = ['google', 'facebook', 'telegram', 'phone'];

export async function findUserByLink(provider, providerUid) {
  const [rows] = await pool.execute(
    `SELECT u.id, u.public_id, u.nickname, u.avatar, u.phone, u.level, u.gender
       FROM linked_accounts l JOIN users u ON u.id = l.user_id
      WHERE l.provider = ? AND l.provider_uid = ? LIMIT 1`,
    [provider, providerUid],
  );
  return rows[0] ?? null;
}

export async function listLinks(userId) {
  const [rows] = await pool.execute(
    'SELECT provider, label, created_at FROM linked_accounts WHERE user_id = ?',
    [userId],
  );
  return rows;
}

/**
 * Attach a sign-in method to a user.
 * Returns 'linked', 'already' (this user already has it) or 'taken' (it belongs to someone else).
 */
export async function linkAccount({ userId, provider, providerUid, label = null }) {
  const owner = await findUserByLink(provider, providerUid);
  if (owner) return String(owner.id) === String(userId) ? 'already' : 'taken';

  const [mine] = await pool.execute(
    'SELECT 1 FROM linked_accounts WHERE user_id = ? AND provider = ? LIMIT 1',
    [userId, provider],
  );
  if (mine.length > 0) return 'already';

  try {
    await pool.execute(
      'INSERT INTO linked_accounts (user_id, provider, provider_uid, label) VALUES (?, ?, ?, ?)',
      [userId, provider, providerUid, label],
    );
    return 'linked';
  } catch (err) {
    if (err?.code === 'ER_DUP_ENTRY') return 'taken';
    throw err;
  }
}

export async function unlinkAccount(userId, provider) {
  const [rows] = await pool.execute(
    'SELECT COUNT(*) AS n FROM linked_accounts WHERE user_id = ?',
    [userId],
  );
  // Never leave an account with no way to sign in.
  if (rows[0].n <= 1) return 'last';
  await pool.execute('DELETE FROM linked_accounts WHERE user_id = ? AND provider = ?', [userId, provider]);
  return 'unlinked';
}

// ---------------------------------------------------------------------------
// Blocked users
// ---------------------------------------------------------------------------

export async function listBlocked(userId) {
  const [rows] = await pool.execute(
    `SELECT u.id, u.public_id, u.nickname, u.avatar
       FROM blocked_users b JOIN users u ON u.id = b.blocked_user_id
      WHERE b.user_id = ? ORDER BY b.created_at DESC`,
    [userId],
  );
  return rows;
}

export async function unblockUser(userId, blockedUserId) {
  await pool.execute(
    'DELETE FROM blocked_users WHERE user_id = ? AND blocked_user_id = ?',
    [userId, blockedUserId],
  );
}

/** Permanently remove an account and everything tied to it. */
export async function deleteUserAccount(userId) {
  const before = await findUserById(userId);
  await pool.execute('DELETE FROM linked_accounts WHERE user_id = ?', [userId]);
  await pool.execute('DELETE FROM blocked_users WHERE user_id = ? OR blocked_user_id = ?', [userId, userId]);
  await pool.execute('DELETE FROM users WHERE id = ?', [userId]);
  if (before?.public_id) await deleteUserDoc(before.public_id);
}
